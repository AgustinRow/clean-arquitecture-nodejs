export const DREAM_ERRORS = {
  hour: {
    text: 'Error: dream must have an hour',
    name: 'hourError',
  },
  date: {
    text: 'Error: dream must have a date',
    name: 'dateError',
  },
};
