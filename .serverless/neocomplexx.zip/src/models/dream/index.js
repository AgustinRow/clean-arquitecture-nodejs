import models from '../index';

const instanceDreamDb = models.Dream;

export default instanceDreamDb;
