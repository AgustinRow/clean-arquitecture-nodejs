import { start } from './deliveries/express/server';
/** START SERVER **/
start();
